#define SECURITY_WIN32 1

#include <Windows.h>
#include <Sspi.h>
