﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Gina.rc
//
#define IDB_BITMAP1                     101
#define IDB_PGINA_LOGO                  101
#define IDD_LOGGEDOUT_SAS               102
#define IDC_LOGO                        1001
#define IDC_MOTD                        1002
#define IDC_USERNAME_LBL                1003
#define IDC_PASSWORD_LBL                1004
#define IDC_USERNAME_TXT                1005
#define IDC_PASSWORD_TXT                1006
#define IDC_EMERGENCY_ESCAPE_HATCH      1007
#define IDC_LOGIN_BUTTON                1008
#define IDC_SHUTDOWN                    1009
#define IDC_SPECIAL                     1010
#define IDC_STATUS                      1011

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
