﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyCompany("pGina Team")]
[assembly: AssemblyProduct("pGina")]
[assembly: AssemblyCopyright("Copyright © pGina Team 2018")]
[assembly: AssemblyTrademark("")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("3.9.9.12")]
[assembly: AssemblyFileVersion("3.9.9.12")]
